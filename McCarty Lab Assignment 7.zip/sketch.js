function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255, 1);
  angleMode(DEGREES);
}

function draw() {
  background(137, 173, 224);
  cloud(100, 120);

  stroke(242, 245, 71);
  strokeWeight(7);
  line(300, 100, 350, 230);
  line(350, 230, 280, 380);

  push();
  rotate(10);
  cloud(320, 75);
  pop();

  push();
  scale(0.5);
  cloud(300, 500);
  pop();

  for (var x = 0; x < width + 200; x += 150) {
    cloud(x, 0);
  }

  print(mouseX / 2);
}

function cloud(x, y) {
  push();
  translate(x, y);
  noStroke();
  fill(55, 59, 64);
  ellipse(0, 0, 150, 100);
  ellipse(50, 0, 100, 100);
  ellipse(-50, 0, 100, 100);
  pop();
}
