//nature scene with trees and rain animation

var r = [];
//var for the rain drops

function setup() {
  createCanvas(400, 400);

  for (var i = 0; i < 3000; i++) {
    r[i] = random(-1000, 200);
    print(r);
    //creating the randomness in the rain, then printing this to console
  }
}

function draw() {
  background(132, 224, 128);
  tree(0, 0);
  tree(100, 50);
  tree(300, 90);
  tree(200, 200);
  tree(50, 350);
  //trees using a specific function and just moving the location

  for (var i = 0; i < r.length; i++) {
    r[i] += 0.5;
    var l = i * 3;
    //control over the speed and spread of the rain

    fill(107, 195, 227);
    stroke(107, 195, 227);
    rect(l, r[i], 2, 20, 50, 50, 50, 50);
    //actual rain color, fill, and shape
  }
}

function tree(x, y) {
  //creating a function for the trees
  push();

  translate(x, y);

  stroke(114, 92, 66);

  fill(114, 92, 66);
  strokeWeight(1);

  rect(0, 0, 30, 200);

  stroke(23, 120, 20);
  fill(23, 99, 20);
  ellipse(15, 0, 200, 150);

  pop();
}
