var cat;
var dog;
var pointer;

function preload() {
  cat = loadImage("cat.jpg");
  dog = loadImage("dog.jpg");
  pointer = loadImage("cursor-png-1120.png");
}

function setup() {
  createCanvas(800, 800);
}

function draw() {
  image(cat, 0, 0);
  image(dog, 100,0, mouseX * 3, mouseY * 3);
  image(pointer, mouseX - 15, mouseY-8, 50, 50);
  stroke(10);
  fill(255);
  textSize(40);
  textFont("Arial");
  text("cat and dog", 300, 300, 100, 200);
}
